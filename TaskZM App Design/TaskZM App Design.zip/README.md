
  # TaskZM App Design

  This is a code bundle for TaskZM App Design. The original project is available at https://www.figma.com/design/FjhIggGGKXyTehlzocF3OE/TaskZM-App-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  